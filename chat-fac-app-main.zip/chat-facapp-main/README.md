# chat-facapp
 Chat proiect facultate scris in Rust si Tauri
